package com.Update;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Demo_Update {

	public void update() throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver Loaded.....");

		Connection cc = DriverManager.getConnection("jdbc:mysql://localhost:3306/ashish", "root", "root");
		System.out.println("Connection Done....");

		Statement ss = cc.createStatement();
		ss.executeUpdate("update shop set Name='Anant' where id=2");

		PreparedStatement pr = cc.prepareStatement("update shop set ProductName=? where id =?");

		pr.setString(1, "Soyabean");
		pr.setInt(2, 6);
		pr.executeUpdate();

		pr.setString(1, "Onion");
		pr.setInt(2, 7);
		pr.executeUpdate();

		Connection close;

	}

}
