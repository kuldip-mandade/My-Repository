package com.Call.Test;

import com.Delete.Demo_Delete;
import com.Insert.Demo_Insert;
import com.Select.Demo_Select;
import com.Update.Demo_Update;

public class Call {

	public static void main(String[] args) throws Exception {

		Demo_Insert di = new Demo_Insert();
		di.insert();

		Demo_Update du = new Demo_Update();
		du.update();

		Demo_Delete dd = new Demo_Delete();
		dd.delete();

		Demo_Select ds = new Demo_Select();
		ds.select();
	}
}
