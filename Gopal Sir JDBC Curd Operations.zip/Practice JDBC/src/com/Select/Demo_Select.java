package com.Select;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Demo_Select {

	public void select() throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver Loaded.....");

		Connection cc = DriverManager.getConnection("jdbc:mysql://localhost:3306/ashish", "root", "root");
		System.out.println("Connection Done.....");

		Statement ss = cc.createStatement();

		System.out.println("Using Statement.....");

		ResultSet re = ss.executeQuery("select * from shop");

		while (re.next()) {
			System.out.println(re.getInt("id") + " \t " + re.getInt("Price") + " \t " + re.getString("Name") + " \t "
					+ re.getString("ProductName"));
		}

		PreparedStatement pr = cc.prepareStatement("select * from shop");

		System.out.println("Using Prepared Statement.....");

		ResultSet rs = pr.executeQuery();

		while (rs.next()) {
			System.out.println(rs.getInt("id") + " \t " + rs.getInt("Price") + " \t " + rs.getString("Name") + " \t "
					+ rs.getString("ProductName"));
		}

		Connection close;

	}
}
