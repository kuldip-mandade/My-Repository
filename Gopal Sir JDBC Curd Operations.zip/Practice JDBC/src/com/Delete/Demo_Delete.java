package com.Delete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Demo_Delete {

	public void delete() throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver Loaded....");

		Connection cc = DriverManager.getConnection("jdbc:mysql://localhost:3306/ashish", "root", "root");
		System.out.println("Connection Done.....");

		Statement ss = cc.createStatement();
		ss.executeUpdate("delete from shop where Name='Anant'");

		PreparedStatement pr = cc.prepareStatement("delete from shop where id=?");

		pr.setInt(1, 4);
		pr.executeUpdate();

		Connection close;

	}

}
