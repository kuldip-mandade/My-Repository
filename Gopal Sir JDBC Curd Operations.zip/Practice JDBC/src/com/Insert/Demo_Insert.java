package com.Insert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Demo_Insert {

	public void insert() throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver Loaded.....");

		Connection cc = DriverManager.getConnection("jdbc:mysql://localhost:3306/ashish", "root", "root");
		System.out.println("Connection Done.....");

		Statement ss = cc.createStatement();
		ss.executeUpdate("insert into shop values('Nikhil',5,'Bajra',15)");

		PreparedStatement pr = cc.prepareStatement("insert into shop (Name,id,ProductName,Price) values(?,?,?,?)");

		pr.setString(1, "Jayesh");
		pr.setInt(2, 6);
		pr.setString(3, "Wheat");
		pr.setInt(4, 40);
		pr.executeUpdate();

		pr.setString(1, "Ritesh");
		pr.setInt(2, 7);
		pr.setString(3, "Rice");
		pr.setInt(4, 35);
		pr.executeUpdate();
		Connection close;
	}
}
